#!/bin/sh

./wait $1
./target $(cat payload)
